package classes;

import java.sql.Connection;
import java.sql.DriverManager;

public class ConectaBD {
	public String usuario="root_senai_pi";
	public String senha="1234";

	public Connection Conectar() throws Exception {
			Class.forName("com.mysql.jdbc.Driver");
			String url = "jdbc:mysql://localhost/senai_604_pi";
	        java.sql.Connection conn = DriverManager.getConnection(url, usuario, senha);

	        return conn;
	}
}